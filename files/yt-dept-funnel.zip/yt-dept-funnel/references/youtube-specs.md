# YouTube公式の仕様（導線に関係する所だけ）

確認日: 2026-11-05（YouTube公式ヘルプの英語版ページを開いて、下の数値と記述を1つずつ照合）
仕様は変わります。使う前に、下の出典URLで最新を確かめてください。ここに無い数字は書きません。
各項目の「原文」は、確認日に公式ヘルプに書かれていた英語の一文です。

## タイトルと説明（概要欄）
- タイトル: 最大100文字（原文: "Video titles have a character limit of 100 characters"）
- 説明: 最大5,000文字（原文: "Video descriptions have a character limit of 5,000 characters"）
- 出典: https://support.google.com/youtube/answer/57404 （2026-11-05確認）

## チャプター（概要欄の目次）
- 最初のタイムスタンプは 00:00（原文: "the first timestamp you list starts with 00:00"）
- タイムスタンプは3つ以上、時刻の早い順（昇順）（原文: "at least three timestamps listed in ascending order"）
- 1つのチャプターは最短10秒（原文: "The minimum length for video chapters is 10 seconds"）
- 出典: https://support.google.com/youtube/answer/9884579 （2026-11-05確認）

## 終了画面
- 動画の長さが25秒以上で付けられる（原文: "at least 25 seconds long to have an end screen"）
- 動画の最後の5〜20秒に表示する（原文: "the last 5–20 seconds of a video"）
- 16:9の動画で、要素は最大4つ（原文: "up to four elements ... standard 16:9 aspect ratio"）
- 外部サイトへのリンク要素は、YouTubeパートナープログラム（YPP）参加者のみ（原文: "If you're in the YouTube Partner Program, you can link to an external website"）
- 子ども向けに設定した動画では使えない（原文: "End screens aren't available for videos set as made for kids"）
- 要素の種類: 動画／再生リスト／登録／チャンネル／リンク（ヘルプの「終了画面を追加する」手順に並ぶもの）
- 動画または再生リストの要素が必ず1つ要るか（登録だけで組めるか）: 公式ヘルプに記載なし（未確認）。YouTube Studio で設定できるか本人が確かめる
- 出典: https://support.google.com/youtube/answer/6388789 （2026-11-05確認）

## カード
- 1本の動画に最大5枚（原文: "You can add up to 5 cards to one video"）
- 種類: 動画／再生リスト／チャンネル／リンク
- リンクカードは YPP参加者のみ（原文: "If you're in the YouTube Partner Program, this info card allows you to link to an external website"）
- 子ども向けに設定した動画では使えない（原文: "Cards aren't available on videos set as made for kids"）
- 出典: https://support.google.com/youtube/answer/6140493 （2026-11-05確認）
- 同じ内容は「チャンネルまたは動画の視聴者層を設定する」の、子ども向けで使えなくなる機能の一覧にも「Cards or end screens」として載っている: https://support.google.com/youtube/answer/9527654 （2026-11-05確認）

## ハッシュタグ
- タイトルの近くに表示されるのは最大3つ（原文: "up to three hashtags ... will appear by your video title"）
- 60個を超えると、その動画のハッシュタグはすべて無視される（原文: "more than 60 hashtags, we'll ignore each hashtag"）
- ハッシュタグにスペースは入れられない（原文: "Hashtags don't contain any spaces"）
- 動画の内容と直接関係のないハッシュタグは付けない（原文: "Don't add hashtags that are not directly related to the video"）
- 出典: https://support.google.com/youtube/answer/6390658 （2026-11-05確認）

## スパム・欺瞞のポリシー（導線に関係する所）
- 内容と違うタイトル・サムネ・説明で誘う（悪質なクリックベイト）は禁止（原文: "Using maliciously misleading titles, thumbnails, descriptions, or imagery to trick users into clicking"）
- 外部サイトへ誘導することだけが目的のコンテンツは禁止（原文: "Content created solely to drive users off of YouTube to external sites"）
- 大量・反復・欺瞞的なコメントは禁止（原文: "Using high-volume, repetitive, or deceptive comments"）
- 出典: https://support.google.com/youtube/answer/2801973 （2026-11-05確認）

## 有料プロモーション
- 商品・サービスの紹介で対価や無償提供を受けていて該当する場合は、YouTube Studio の動画の詳細（「もっと見る」の中の有料プロモーションの欄）で申告する。英語版の画面では "Paid Promotion" の欄で "Yes, my video includes branded content" を選ぶと書かれている。日本語版の画面での表記は未確認
- 法的な開示義務への対応はクリエイター本人の責任（原文: "responsible for understanding and complying with all applicable legal requirements"）
- このスキルは法的な判断をしない。確認ポイントを示し、本人が公式・専門家で確かめる
- 出典: https://support.google.com/youtube/answer/154235 （2026-11-05確認）

## 公式に記載がないもの（断定しない）
- 「もっと見る」の前に説明が何行見えるか: 公式ヘルプで決まった数の記載を確認できていない（未確認）。端末・画面で変わる前提で、大事なことを最初の2行に置く
