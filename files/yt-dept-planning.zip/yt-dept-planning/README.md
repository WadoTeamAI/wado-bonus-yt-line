# 企画・競合リサーチ担当AI社員（yt-dept-planning）配布版

YouTube部署の「企画・競合リサーチ担当」です。伸びている動画の型を3つに分け、あなたが答えられる企画を10本とタイトル案を出します。競合1本の深掘り分析もできます。

## 動作条件

- Claude Code（macOS / Windows / Linux）
- スクリプトは使いません（追加のインストールは不要です）

## インストール

```bash
unzip yt-dept-planning.zip -d ~/.claude/skills/
```

## 1分の動作確認

Claude Code を開き、「企画を10本出して」「この競合動画を分析して」 と話しかけます。足りない情報があれば、AI社員の方から質問が返ってきます。

## 困ったとき

| 症状 | 対処 |
|---|---|
| スキルが呼ばれない | `/yt-dept-planning` と打って直接呼び出す |
| 毎回同じことを聞かれる | `youtube/channel-profile.md`（チャンネル設定）を作ると読み込みます。雛形は台本担当・チャンネル設計担当に同梱 |
| 数字や実績を書いてほしい | 自分で出典つきで渡した数字だけを使います。AIは数字を作りません |

## 同梱物

| ファイル | 中身 |
|---|---|
| `SKILL.md` | AI社員の手順と判断の基準 |
| `references/knowledge.md` | ナレッジ（考え方・判断の基準） |
| `references/good-output.md` | 正しいアウトプット（完成見本） |
| `references/competitor-list-template.md` | 競合リストの雛形 |
| `references/planning-criteria.md` | 企画の採否の条件・タイトルの型 |
| `README.md` | このファイル |

## 配布範囲

公式LINEに登録した方への特典です。再配布はご遠慮ください。※成果には個人差があります。
