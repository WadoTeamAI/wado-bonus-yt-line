# 企画・競合リサーチ担当AI社員（yt-dept-planning）配布版 v2

YouTube部署の「企画・競合リサーチ担当」です。届けたい相手の検索語で伸びている動画を自分で集め、チャンネルの大きさに比べて伸びているかを判定します（再生数÷登録者数・チャンネル中央値比）。そのうえで、あなたが答えられる企画を10本出して採点し、10種類の型でタイトル案を作り、撮る1本を推薦します。競合チャンネルの深掘り分析もできます。

## 動作条件

- Claude Code（macOS / Windows / Linux）
- 追加のインストールは不要です（Web検索で材料を集めます＝方法A）
- 任意: yt-dlp を入れると、再生数・登録者数・投稿日を正確に取れます（方法B）
- 任意（上級者）: YouTube Data API のキーを用意すると、全動画の投稿日・コメント数まで取れます（方法C）

## インストール

```bash
unzip yt-dept-planning.zip -d ~/.claude/skills/
```

### 任意: yt-dlp を入れる（方法B）

```bash
brew install yt-dlp        # macOS（Homebrew）
pip install yt-dlp         # どのOSでも（Python がある場合）
```

確認: `python3 ~/.claude/skills/yt-dept-planning/scripts/yt_research.py search "動画編集 続かない" --n 10`

### 任意（上級者）: YouTube Data API のキー（方法C）

1. Google Cloud でプロジェクトを作り、「YouTube Data API v3」を有効にする
2. 「認証情報」でAPIキーを作り、使えるAPIを YouTube Data API v3 に制限する
3. ターミナルで `export YOUTUBE_API_KEY=作ったキー` を設定する（キーは人に見せない・共有しない）

キーがあると、同じスクリプトが自動で方法Cを使います。無料の利用枠と条件は公式の最新ページで確認してください。

## 1分の動作確認

Claude Code を開き、「届けたい相手は『副業で動画を始めたい会社員』です。企画を10本出して」と話しかけます。届けたい相手が分からないときだけ、AI社員から質問が返ってきます。

## 困ったとき

| 症状 | 対処 |
|---|---|
| スキルが呼ばれない | `/yt-dept-planning` と打って直接呼び出す |
| 毎回同じことを聞かれる | `youtube/channel-profile.md`（チャンネル設定）を作ると読み込みます。雛形は台本担当・チャンネル設計担当に同梱 |
| 伸び判定が「不明」「判定しない」ばかり | Web検索では登録者数などが取れないことがあります。yt-dlp を入れると正確に取れます |
| `yt-dlp が見つかりません`（exit 2） | 方法A（Web検索）で進みます。正確な数字が要るときだけ yt-dlp を入れてください |
| `YouTube API 403`（exit 3） | APIキーの誤りか、1日の利用枠の使い切りです。翌日まで待つか、`--source ytdlp` で方法Bを使ってください |
| 数字や実績を書いてほしい | 自分で出典つきで渡した数字と、取得した数字だけを使います。AIは数字を作りません |

## 同梱物

| ファイル | 中身 |
|---|---|
| `SKILL.md` | AI社員の手順と判断の基準（v2.0.0） |
| `references/knowledge.md` | ナレッジ（考え方・判断の基準） |
| `references/research-method.md` | 材料の集め方（方法A・B・C、検索語の作り方、リサーチ記録） |
| `references/planning-criteria.md` | 伸び判定のルール・企画の採点・採否の条件 |
| `references/title-patterns.md` | タイトルの型10個と守る基準 |
| `references/video-formats.md` | 企画の型8個 |
| `references/good-output.md` | 正しいアウトプット（完成見本） |
| `references/competitor-list-template.md` | 競合リストの雛形 |
| `scripts/yt_research.py` | リサーチの道具（任意。yt-dlp か APIキーがあるときに使う） |
| `output/261029_planning-real-run.md` | 実際の成果物（このAI社員を、わどのYouTubeチャンネルの材料で動かした出力。競合名・数字は伏せています） |
| `requirements.txt` | 任意で入れるもの（yt-dlp） |
| `README.md` | このファイル |

## 次の一歩: セミナーのオープンチャットに参加する

この特典は、セミナー「AIエージェント × 完全YouTube攻略 0→100ロードマップセミナー」の企画でお届けしています。セミナーのご案内は、企画のオープンチャットにまとめています。

▶ オープンチャットに参加する: https://line.me/ti/g2/XwfWeJRx4pIp7VlHv3ESOuFbvvBgRmcS76PWSQ?utm_source=invitation&utm_medium=link_copy&utm_campaign=default

## 配布範囲

公式LINEに登録した方への特典です。再配布はご遠慮ください。※成果には個人差があります。
