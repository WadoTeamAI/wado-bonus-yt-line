#!/usr/bin/env python3
"""
yt_research.py ── YouTube の検索結果・チャンネルの動画を集めて、「伸びている動画」の判定表を Markdown で出す。

企画・競合リサーチ担当（yt-dept-planning）の「方法B／方法C」。どちらも任意の道具。
  方法B: yt-dlp ＋ YouTube 公式のチャンネルRSS（キー不要）
  方法C: YouTube Data API v3（上級者向け。環境変数 YOUTUBE_API_KEY を自分で用意した人だけ）
--source auto（既定）は、YOUTUBE_API_KEY があれば C、無ければ B。
どちらも使えなければ exit 2 で「方法A（Web検索）で進めてください」と案内する。

取るもの（取れた値だけ。取れない値は「不明」と書き、推測で埋めない）:
  - 検索結果の タイトル・再生数・長さ・チャンネル        … yt-dlp（検索結果の一覧）
  - チャンネル登録者数                                  … yt-dlp（チャンネルページ）
  - 直近の動画の再生数・投稿日（最大15本）              … YouTube 公式のチャンネルRSS（キー不要）
方法Cで取るもの: 上と同じ値＋全動画の投稿日・コメント数・チャンネルの直近20本（RSSの15本制限なし）
伸び指標（目安。判定ルールは references/planning-criteria.md）:
  - 指標1 = 再生数 ÷ 登録者数（1.0以上＝候補、3.0以上＝強い）
  - 指標2 = 再生数 ÷ そのチャンネルの直近の長尺動画の再生数の中央値（2.0倍以上＝候補）
  - 投稿30日未満は「暫定」。登録者が非公開・取れない値は、その指標で判定しない

使い方:
  python3 yt_research.py search "Claude Code 副業" --n 20
  python3 yt_research.py channel https://www.youtube.com/@example --n 30
  python3 yt_research.py search "動画編集 副業" --dry-run      # 何を取りに行くかだけ表示（通信しない）
  YOUTUBE_API_KEY=... python3 yt_research.py search "Claude Code 副業" --source api
  python3 yt_research.py selftest                                # 通信なしの動作確認

方法Bは外部APIキー不要。YouTube へは読み取りのみ（投稿・ログインはしない）。APIキーは画面・ログに出さない。
"""

import argparse
import datetime as dt
import json
import os
import re
import shutil
import statistics
import subprocess
import sys
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

RSS_URL = "https://www.youtube.com/feeds/videos.xml?channel_id={cid}"
NS = {"a": "http://www.w3.org/2005/Atom", "yt": "http://www.youtube.com/xml/schemas/2015",
      "media": "http://search.yahoo.com/mrss/"}
NO_YTDLP = (
    "yt-dlp が見つかりません。方法A（Web検索で集める）で進めてください。\n"
    "数字を正確に取りたい場合は、yt-dlp を入れてから再実行します:\n"
    "  macOS: brew install yt-dlp   /   共通: pip install yt-dlp"
)
API = "https://www.googleapis.com/youtube/v3/"
LONG_MIN_SEC = 180  # 方法Cの中央値はショートを除く（3分以下を除外）
NO_SOURCE = (
    "yt-dlp も YOUTUBE_API_KEY も見つかりません。方法A（Web検索で集める）で進めてください。\n"
    "数字を正確に取りたい場合は、どちらかを用意して再実行します:\n"
    "  方法B: brew install yt-dlp   /   pip install yt-dlp\n"
    "  方法C（上級者）: Google Cloud で YouTube Data API v3 のAPIキーを作り、export YOUTUBE_API_KEY=... を設定"
)
STRONG_1, CAND_1, CAND_2, PROVISIONAL_DAYS = 3.0, 1.0, 2.0, 30
MIN_VIEWS = 1000  # これ未満は母数が小さすぎて比率がぶれる（登録者6人・再生37回が「強い」になる例を実測）


def find_ytdlp(explicit: str | None = None) -> list[str] | None:
    """yt-dlp の起動コマンドを返す。無ければ None。"""
    if explicit:
        return [explicit] if shutil.which(explicit) else None
    if shutil.which("yt-dlp"):
        return ["yt-dlp"]
    try:
        import yt_dlp  # noqa: F401
        return [sys.executable, "-m", "yt_dlp"]
    except ImportError:
        return None


def run_json(ytdlp: list[str], args: list[str], timeout: int = 120, ja: bool = False) -> dict | None:
    # ja=True は検索結果のタイトルを日本語で受け取るため（自動翻訳タイトル対策）。
    # チャンネルページに付けると登録者数を読めなくなる（2026-10 実測）ので、検索だけに付ける
    cmd = ytdlp + ["--flat-playlist", "-J", "--no-warnings", "--no-update"]
    cmd += ["--extractor-args", "youtube:lang=ja"] if ja else []
    cmd += args
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        print(f"[WARN] 時間切れ: {' '.join(args)}", file=sys.stderr)
        return None
    if r.returncode != 0:
        print(f"[WARN] yt-dlp 失敗 exit {r.returncode}: {r.stderr.strip()[-300:]}", file=sys.stderr)
        return None
    try:
        return json.loads(r.stdout)
    except json.JSONDecodeError:
        return None


def fetch_rss(cid: str) -> dict[str, dict]:
    """チャンネルRSSから直近の動画（最大15本）の 再生数・投稿日 を返す。取れなければ空。"""
    try:
        req = urllib.request.Request(RSS_URL.format(cid=cid), headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=20) as f:
            root = ET.fromstring(f.read())
    except Exception as e:  # 通信断・404 は「不明」で続ける
        print(f"[WARN] RSS 取得できず {cid}: {e}", file=sys.stderr)
        return {}
    out = {}
    for ent in root.findall("a:entry", NS):
        vid = ent.findtext("yt:videoId", default="", namespaces=NS)
        pub = ent.findtext("a:published", default="", namespaces=NS)
        st = ent.find("media:group/media:community/media:statistics", NS)
        views = int(st.get("views")) if st is not None and st.get("views", "").isdigit() else None
        out[vid] = {"views": views, "published": pub[:10] or None}
    return out


def channel_info(ytdlp: list[str], url_or_id: str, n: int = 30) -> dict:
    """登録者数・長尺動画の一覧（id・タイトル）・RSS を合わせたチャンネル情報。"""
    url = url_or_id if url_or_id.startswith("http") else f"https://www.youtube.com/channel/{url_or_id}"
    url = url.rstrip("/")
    if not re.search(r"/(videos|shorts|streams)$", url):
        url += "/videos"
    d = run_json(ytdlp, ["--playlist-end", str(n), url]) or {}
    cid = d.get("channel_id") or (url_or_id if url_or_id.startswith("UC") else None)
    rss = fetch_rss(cid) if cid else {}
    long_ids = [e.get("id") for e in d.get("entries") or [] if e.get("id")]
    # 中央値は「長尺タブにある動画」×「RSSで再生数が取れた動画」。重なりが無ければRSS全体（ショート混在）で代用
    pool = [rss[i]["views"] for i in long_ids if i in rss and rss[i]["views"] is not None]
    mixed = False
    if not pool:
        pool = [v["views"] for v in rss.values() if v["views"] is not None]
        mixed = bool(pool)
    return {
        "channel_id": cid, "channel": d.get("channel") or d.get("uploader"),
        "subscribers": d.get("channel_follower_count"), "entries": d.get("entries") or [],
        "rss": rss, "median": statistics.median(pool) if pool else None, "median_n": len(pool),
        "median_mixed_shorts": mixed,
    }


class ApiStop(Exception):
    """401/403/429 など、再試行しても直らないエラー（枠切れ・キー不正）。"""


def api_get(key: str, endpoint: str, **params) -> dict:
    q = urllib.parse.urlencode({**params, "key": key})
    try:
        with urllib.request.urlopen(API + endpoint + "?" + q, timeout=30) as f:
            return json.loads(f.read())
    except urllib.error.HTTPError as e:
        try:
            reason = json.loads(e.read())["error"]["errors"][0]["reason"]
        except Exception:
            reason = "unknown"
        if e.code in (400, 401, 403, 429):
            raise ApiStop(f"YouTube API {e.code} {reason}（キー・枠を確認。再試行しません）") from None
        raise


def iso_dur(s: str | None) -> int | None:
    m = re.match(r"P(?:(\d+)D)?T?(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?", s or "")
    if not m or not s:
        return None
    d, h, mi, se = (int(x or 0) for x in m.groups())
    return d * 86400 + h * 3600 + mi * 60 + se


def api_videos(key: str, ids: list[str]) -> list[dict]:
    out = []
    for i in range(0, len(ids), 50):
        d = api_get(key, "videos", part="snippet,statistics,contentDetails", id=",".join(ids[i:i + 50]))
        for it in d.get("items", []):
            st, sn = it.get("statistics", {}), it.get("snippet", {})
            out.append({"id": it["id"], "title": sn.get("title"), "channel": sn.get("channelTitle"),
                        "channel_id": sn.get("channelId"), "date": (sn.get("publishedAt") or "")[:10] or None,
                        "views": int(st["viewCount"]) if "viewCount" in st else None,
                        "comments": int(st["commentCount"]) if "commentCount" in st else None,
                        "duration": iso_dur(it.get("contentDetails", {}).get("duration"))})
    return out


def api_channel(key: str, cid: str | None = None, handle: str | None = None, n: int = 20) -> dict:
    p = {"id": cid} if cid else {"forHandle": handle}
    items = api_get(key, "channels", part="snippet,statistics,contentDetails", **p).get("items", [])
    if not items:
        return {"channel_id": cid, "channel": None, "subscribers": None, "median": None, "median_n": 0, "videos": []}
    it = items[0]
    st = it.get("statistics", {})
    subs = None if st.get("hiddenSubscriberCount") else (int(st["subscriberCount"]) if "subscriberCount" in st else None)
    uploads = it.get("contentDetails", {}).get("relatedPlaylists", {}).get("uploads")
    ids = []
    if uploads:
        pl = api_get(key, "playlistItems", part="contentDetails", playlistId=uploads, maxResults=min(n, 50))
        ids = [x["contentDetails"]["videoId"] for x in pl.get("items", [])]
    vids = api_videos(key, ids) if ids else []
    pool = [v["views"] for v in vids if v["views"] is not None and (v["duration"] or 0) > LONG_MIN_SEC]
    return {"channel_id": it["id"], "channel": it.get("snippet", {}).get("title"), "subscribers": subs,
            "median": statistics.median(pool) if pool else None, "median_n": len(pool), "videos": vids}


def days_since(date_str: str | None, today: dt.date) -> int | None:
    if not date_str:
        return None
    try:
        return (today - dt.date.fromisoformat(date_str[:10])).days
    except ValueError:
        return None


def judge(views, subs, median, age_days) -> dict:
    """伸び指標と判定。取れない値の指標は None（判定に使わない）。"""
    i1 = round(views / subs, 2) if views is not None and subs else None
    i2 = round(views / median, 2) if views is not None and median else None
    if i1 is None and i2 is None:
        verdict = "判定しない（値が不足）"
    elif views < MIN_VIEWS:
        verdict = "参考外（再生1,000回未満）"
    elif i1 is not None and i1 >= STRONG_1:
        verdict = "強い"
    elif (i1 is not None and i1 >= CAND_1) or (i2 is not None and i2 >= CAND_2):
        verdict = "候補"
    else:
        verdict = "対象外"
    if age_days is not None and age_days < PROVISIONAL_DAYS and verdict[:2] in ("強い", "候補", "対象"):
        verdict += "（暫定・投稿30日未満）"
    return {"i1": i1, "i2": i2, "verdict": verdict}


def fmt(v, kind="int") -> str:
    if v is None:
        return "不明"
    if kind == "int":
        return f"{int(v):,}"
    if kind == "dur":
        s = int(v)
        return f"{s // 60}:{s % 60:02d}"
    return str(v)


def table(rows: list[dict]) -> str:
    head = "| No | タイトル | チャンネル | 登録者 | 再生数 | コメント | 投稿日 | 長さ | 指標1 再生÷登録者 | 指標2 中央値比 | 判定 | URL |\n"
    head += "|---|---|---|---|---|---|---|---|---|---|---|---|\n"
    lines = []
    for i, r in enumerate(rows, 1):
        title = (r["title"] or "不明").replace("|", "｜")
        lines.append(f"| {i} | {title} | {(r['channel'] or '不明').replace('|', '｜')} | {fmt(r['subs'])} | {fmt(r['views'])} | {fmt(r.get('comments'))} | "
                     f"{fmt(r['date'], 'str')} | {fmt(r['duration'], 'dur')} | {fmt(r['i1'], 'str')} | {fmt(r['i2'], 'str')} | "
                     f"{r['verdict']} | https://www.youtube.com/watch?v={r['id']} |")
    return head + "\n".join(lines)


def missing_summary(rows: list[dict]) -> str:
    keys = {"subs": "登録者数", "views": "再生数", "date": "投稿日", "i2": "チャンネル中央値比"}
    parts = [f"{label} {sum(1 for r in rows if r.get(k) is None)}件" for k, label in keys.items()
             if any(r.get(k) is None for r in rows)]
    return "、".join(parts) if parts else "なし"


def header(mode: str, target: str, n_rows: int, source: str = "ytdlp") -> str:
    now = dt.datetime.now().strftime("%Y-%m-%d %H:%M")
    label = "方法C: YouTube Data API" if source == "api" else "方法B: yt-dlp＋公式RSS"
    return (f"## リサーチ記録（{label}）\n"
            f"- 取得日時: {now}\n- {'検索語' if mode == 'search' else 'チャンネル'}: {target}\n- 取得件数: {n_rows}\n")


def footer(rows: list[dict]) -> str:
    return (f"\n- 取れなかった値: {missing_summary(rows)}（「不明」は推測で埋めない）\n"
            "- しきい値は目安です（指標1: 1.0以上＝候補／3.0以上＝強い、指標2: 2.0倍以上＝候補、投稿30日未満は暫定、再生1,000回未満は参考外）\n"
            "- 届けたい相手の悩みと関係ない動画（検索語が偶然一致したもの）は、伸び判定表に移すときに外す\n"
            "- 伸びていることは需要の参考です。内容の正しさや、伸びた理由の証明ではありません\n")


def cmd_search(a, ytdlp) -> int:
    q = f"ytsearch{a.n}:{a.query}"
    if a.dry_run:
        print(f"[DRY-RUN] 検索: {' '.join(ytdlp)} --flat-playlist -J \"{q}\"")
        print("[DRY-RUN] 各チャンネル: yt-dlp で登録者数 / 公式RSSで直近15本の再生数・投稿日 を取得")
        return 0
    d = run_json(ytdlp, [q], ja=True)
    if not d:
        print("[ERROR] 検索結果を取得できませんでした。時間をおくか、方法A（Web検索）で進めてください。", file=sys.stderr)
        return 1
    today = dt.date.today()
    cache: dict[str, dict] = {}
    rows = []
    for e in d.get("entries") or []:
        cid = e.get("channel_id")
        if cid and cid not in cache and not a.no_channel:
            cache[cid] = channel_info(ytdlp, cid, 30)
        ch = cache.get(cid, {})
        rss_hit = ch.get("rss", {}).get(e.get("id"), {})
        views = e.get("view_count") if e.get("view_count") is not None else rss_hit.get("views")
        date = rss_hit.get("published")
        age = days_since(date, today)
        j = judge(views, ch.get("subscribers"), ch.get("median"), age)
        rows.append({"id": e.get("id"), "title": e.get("title"), "channel": e.get("channel") or ch.get("channel"),
                     "subs": ch.get("subscribers"), "views": views, "date": date, "duration": e.get("duration"), **j})
    if a.json:
        print(json.dumps(rows, ensure_ascii=False, indent=2))
        return 0
    print(header("search", a.query, len(rows)))
    print(table(rows))
    print(footer(rows))
    print("- 投稿日はチャンネルの直近15本に入っている動画だけ取れます（古い動画は「不明」。必要なら動画ページで確認）")
    return 0


def cmd_channel(a, ytdlp) -> int:
    if a.dry_run:
        print(f"[DRY-RUN] チャンネル: {' '.join(ytdlp)} --flat-playlist -J --playlist-end {a.n} \"{a.url}/videos\"")
        print("[DRY-RUN] 公式RSSで直近15本の再生数・投稿日を取得")
        return 0
    ch = channel_info(ytdlp, a.url, a.n)
    if not ch["entries"] and not ch["rss"]:
        print("[ERROR] チャンネルの動画を取得できませんでした。URLを確認するか、方法A（Web検索）で進めてください。", file=sys.stderr)
        return 1
    today = dt.date.today()
    entries = ch["entries"] or [{"id": k, "title": None} for k in ch["rss"]]
    rows = []
    for e in entries:
        hit = ch["rss"].get(e.get("id"), {})
        views = e.get("view_count") if e.get("view_count") is not None else hit.get("views")
        date = hit.get("published")
        j = judge(views, ch["subscribers"], ch["median"], days_since(date, today))
        rows.append({"id": e.get("id"), "title": e.get("title"), "channel": ch["channel"], "subs": ch["subscribers"],
                     "views": views, "date": date, "duration": e.get("duration"), **j})
    if a.json:
        print(json.dumps({"channel": {k: ch[k] for k in ("channel", "channel_id", "subscribers", "median", "median_n")},
                          "rows": rows}, ensure_ascii=False, indent=2))
        return 0
    print(header("channel", f"{ch['channel'] or '不明'}（{a.url}）", len(rows)))
    note = "（ショート混在で代用）" if ch["median_mixed_shorts"] else ""
    print(f"- 登録者数: {fmt(ch['subscribers'])} / 直近の再生数の中央値: {fmt(ch['median'])}（{ch['median_n']}本{note}）\n")
    print(table(rows))
    print(footer(rows))
    print("- 再生数・投稿日は公式RSSに出る直近15本だけ取れます。それより古い動画は「不明」です")
    return 0


def emit(a, mode: str, target: str, rows: list[dict], source: str, extra: str = "") -> int:
    if a.json:
        print(json.dumps(rows, ensure_ascii=False, indent=2))
        return 0
    print(header(mode, target, len(rows), source))
    if extra:
        print(extra)
    print(table(rows))
    print(footer(rows))
    return 0


def cmd_search_api(a, key: str) -> int:
    if a.dry_run:
        print(f"[DRY-RUN] 方法C: search.list q=\"{a.query}\" maxResults={min(a.n, 50)}（枠100）→ videos.list / channels.list / playlistItems.list（各1）")
        return 0
    d = api_get(key, "search", part="snippet", type="video", q=a.query, maxResults=min(a.n, 50),
                relevanceLanguage="ja", regionCode="JP")
    ids = [x["id"]["videoId"] for x in d.get("items", []) if x.get("id", {}).get("videoId")]
    vids = api_videos(key, ids)
    order = {v: i for i, v in enumerate(ids)}
    vids.sort(key=lambda v: order.get(v["id"], 999))
    today, cache, rows = dt.date.today(), {}, []
    for v in vids:
        cid = v["channel_id"]
        if cid and cid not in cache and not a.no_channel:
            cache[cid] = api_channel(key, cid=cid)
        ch = cache.get(cid, {})
        j = judge(v["views"], ch.get("subscribers"), ch.get("median"), days_since(v["date"], today))
        rows.append({**v, "subs": ch.get("subscribers"), **j})
    return emit(a, "search", a.query, rows, "api")


def cmd_channel_api(a, key: str) -> int:
    if a.dry_run:
        print(f"[DRY-RUN] 方法C: channels.list → playlistItems.list（直近{min(a.n, 50)}本）→ videos.list（各1）")
        return 0
    m = re.search(r"/channel/(UC[\w-]+)", a.url) or re.match(r"(UC[\w-]{20,})$", a.url)
    h = re.search(r"/(@[^/?]+)", a.url) or re.match(r"(@[^/?]+)$", a.url)
    if not m and not h:
        print("[ERROR] チャンネルURLは https://www.youtube.com/@ハンドル か /channel/UC... の形で渡してください。", file=sys.stderr)
        return 1
    ch = api_channel(key, cid=m.group(1) if m else None, handle=None if m else urllib.parse.unquote(h.group(1)), n=a.n)
    if not ch["videos"]:
        print("[ERROR] チャンネルの動画を取得できませんでした。URLを確認してください。", file=sys.stderr)
        return 1
    today = dt.date.today()
    rows = [{**v, "subs": ch["subscribers"], **judge(v["views"], ch["subscribers"], ch["median"], days_since(v["date"], today))}
            for v in ch["videos"]]
    extra = f"- 登録者数: {fmt(ch['subscribers'])} / 直近の長尺動画の再生数の中央値: {fmt(ch['median'])}（{ch['median_n']}本・3分以下を除く）\n"
    return emit(a, "channel", f"{ch['channel'] or '不明'}（{a.url}）", rows, "api", extra)


def cmd_selftest() -> int:
    """通信なしで、判定ロジックと「yt-dlp なし」の案内を確かめる。"""
    ok = True
    cases = [
        ((30000, 10000, None, 100), "強い"),           # 指標1 = 3.0
        ((12000, 10000, None, 100), "候補"),           # 指標1 = 1.2
        ((5000, 10000, 2000, 100), "候補"),            # 指標1 = 0.5 だが 指標2 = 2.5
        ((5000, 10000, 4000, 100), "対象外"),
        ((5000, None, None, 100), "判定しない（値が不足）"),  # 登録者非公開
        ((50000, 10000, None, 10), "強い（暫定・投稿30日未満）"),
        ((37, 6, 15, 100), "参考外（再生1,000回未満）"),     # 極小チャンネル
    ]
    for args, want in cases:
        got = judge(*args)["verdict"]
        mark = "OK" if got == want else "NG"
        ok &= got == want
        print(f"[{mark}] judge{args} = {got}")
    for s_in, want in (("PT20M15S", 1215), ("PT1H2M3S", 3723), ("PT45S", 45), (None, None)):
        got = iso_dur(s_in)
        ok &= got == want
        print(f"[{'OK' if got == want else 'NG'}] iso_dur({s_in}) = {got}")
    absent = find_ytdlp("yt-dlp-does-not-exist-xyz")
    print(f"[{'OK' if absent is None else 'NG'}] yt-dlp が無いときは None（本番では exit 2＋方法Aの案内）")
    ok &= absent is None
    print("[SUCCESS] selftest" if ok else "[ERROR] selftest")
    return 0 if ok else 1


def main() -> int:
    p = argparse.ArgumentParser(description="YouTube の伸びている動画を集めて判定表を出す（yt-dlp・任意）")
    p.add_argument("--ytdlp-bin", help="yt-dlp の実行ファイル名（通常は不要）")
    p.add_argument("--source", choices=["auto", "ytdlp", "api"], default="auto",
                   help="auto=YOUTUBE_API_KEY があれば方法C、無ければ方法B（既定）")
    sub = p.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("search", help="検索語で集める")
    s.add_argument("query")
    s.add_argument("--n", type=int, default=20, help="取得件数（既定20）")
    s.add_argument("--no-channel", action="store_true", help="登録者数・中央値を取りに行かない（速いが判定できない）")
    c = sub.add_parser("channel", help="1チャンネルの動画を集める（競合1本の深掘り・自分のチャンネルの確認）")
    c.add_argument("url")
    c.add_argument("--n", type=int, default=30, help="取得件数（既定30。再生数が取れるのは直近15本）")
    for sp in (s, c):
        sp.add_argument("--dry-run", action="store_true", help="通信せず、取りに行く内容だけ表示")
        sp.add_argument("--json", action="store_true", help="表ではなくJSONで出す")
    sub.add_parser("selftest", help="通信なしの動作確認")
    a = p.parse_args()
    if a.cmd == "selftest":
        return cmd_selftest()
    key = os.environ.get("YOUTUBE_API_KEY", "").strip()
    if a.source == "api" or (a.source == "auto" and key):
        if not key:
            print("[ERROR] --source api には環境変数 YOUTUBE_API_KEY が必要です。\n" + NO_SOURCE, file=sys.stderr)
            return 2
        try:
            return cmd_search_api(a, key) if a.cmd == "search" else cmd_channel_api(a, key)
        except ApiStop as e:
            print(f"[ERROR] {e}", file=sys.stderr)
            return 3
    ytdlp = find_ytdlp(a.ytdlp_bin)
    if ytdlp is None:
        print(NO_YTDLP if a.source == "ytdlp" else NO_SOURCE, file=sys.stderr)
        return 2
    return cmd_search(a, ytdlp) if a.cmd == "search" else cmd_channel(a, ytdlp)


if __name__ == "__main__":
    sys.exit(main())
